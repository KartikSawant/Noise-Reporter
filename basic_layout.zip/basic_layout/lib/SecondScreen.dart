import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'constant.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'description.dart';
import 'dart:io';
import 'package:basic_layout/shimmer.dart';
import 'package:flutter/animation.dart';

class BusinessPage extends StatelessWidget {
  static String tag = "BusinessPage-tag";
  BusinessPage(this.text);
  final int text;

  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(

      body: new SafeArea(
          child: new Column(
            children: [
              new Expanded(
                flex: 1,
                child: new Container(
                    width: width,
                    color: Colors.white,
                    child: new GestureDetector(
                      child: new FutureBuilder<List<News>>(
                        future: fetchNews(
                            http.Client(), text),
                        builder: (context, snapshot) {
                          if (snapshot.hasError) print(snapshot.error);
                          return snapshot.hasData
                              ? NewsList(news: snapshot.data)
                              : Center(child: CircularProgressIndicator());
                        },
                      ),
                    )),
              ),
            ],
          )),
    );
  }
}

Future<List<News>> fetchNews(http.Client client, id) async {
  String url;
  url = Constant.base_url +
      "top-headlines?country=us&category=science&apiKey=" +
      Constant.key;
  final response = await client.get(url);
  return compute(parsenews, response.body);
}

List<News> parsenews(String responsebody) {
  final parsed = json.decode(responsebody);
  return (parsed["articles"] as List)
      .map<News>((json) => new News.fromJson(json))
      .toList();
}
bool _visible = true;
class News {
  String author;
  String title;
  String description;
  String url;
  String image;

  News({this.author, this.title, this.description, this.url, this.image});

  factory News.fromJson(Map<String, dynamic> json) {
    return News(
      author: json['author'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      url: json['url'] as String,
      image: json['urlToImage'] as String,
    );
  }
}


class NewsList extends StatelessWidget {
  final List<News> news;
  NewsList({Key key, this.news}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: news.length,
      itemBuilder: (context, index) {
        var image = news[index].image;
        Timer timer = Timer(Duration(seconds: 5), () {
          _visible=false;
        }
        );
        return new Card(
          child: new ListTile(
            leading: FadeInImage.assetNetwork(  placeholder: 'assets/images/place.png', image: image,width: 90.0,),
            title: Stack(
              children: <Widget>[
                  AnimatedOpacity(

                    opacity: _visible ? 1.0: 0.0,
                    duration: Duration(seconds: 2),
                    child: Shimmer(
                      child: Column(
                        children: <Widget>[
                          Container(
                            height: 20.0,
                            color: Colors.white,
                          ),
                          Divider(
                            height: 20.0,
                            color: Colors.transparent,
                          ),
                          Container(
                            height: 20.0,
                            color: Colors.white,
                          ),
                          Divider(
                            height: 20.0,
                            color: Colors.transparent,
                          ),
                          Container(
                            height: 20.0,
                            color: Colors.white,
                          ),
                        ],
                      ),
                      gradient: LinearGradient(begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        stops: [0.1, 0.5, 0.9],
                        colors: [
                          Colors.grey,
                          Colors.white,
                          Colors.grey,
                        ],
                      ),
                      loop: 2,
                    )
                  ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(news[index].title),
                ),
              ],

            ),
            onTap: () {
              var image = news[index].image;
              print(image);
              var url = news[index].url;
              var title = news[index].title;
              Navigator.push(
                  context,
                  new MaterialPageRoute(
                    builder: (BuildContext context) => new WebPage(url,title),
                  ));
            },
          ),
        );
      },
    );
  }
}