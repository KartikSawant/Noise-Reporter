import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:basic_layout/Login.dart';
import 'package:basic_layout/FirstScreen.dart';
import 'package:basic_layout/SecondScreen.dart';
import 'package:basic_layout/CleanScreen.dart';
void main() async {

  runApp(MaterialApp(
    title: 'News',
    home: MyApp(),
  ));
}
class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new AppStates();
  }
}
class AppStates extends State<MyApp> {


  var text= 'New User';
  var log="Login";

  Widget build(BuildContext context) {
    return MaterialApp(
      theme: new ThemeData(
        fontFamily: 'Raleway',
        primarySwatch: Colors.blue,
        indicatorColor: Colors.white,
      ),
      title: 'News App',
      home: DefaultTabController(
        length: 6,
        child: Scaffold(
          appBar: AppBar(
            bottom: new PreferredSize(
              preferredSize: new Size(50.0, 50.0),
              child: new Container(
                color: Colors.blue[900],
                child: new TabBar(
                  isScrollable: true,
                  tabs: [
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Tab1'),
                    ),
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Science'),
                    ),
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Business'),
                    ),
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Tech'),
                    ),
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Flutter'),
                    ),
                    new Container(
                      height: 50.0,
                      child: new Tab(text: 'Apple'),
                    ),
                  ],
                ),
              ),
            ),
            title:Image.asset('assets/images/logo.png'),

          ),
          body: TabBarView(
            children: [
              FirstScreen(),
              BusinessPage(1),
              SavePage(4),
              SavePage(3),
              SavePage(5),
              SavePage(4),
            ],
          ),

          drawer: new Drawer(
              child: new ListView(
                children: <Widget>[
                  new DrawerHeader(
                    child:
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only( right: 8.0, bottom: 8.0, top:8.0),
                              child: Image.asset('assets/images/user.png', width: 50.0,),
                            ),
                            new Divider(),
                            Padding(
                              padding: const EdgeInsets.only(top: 34.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: new Text(text,style: new TextStyle(fontSize: 20.0),),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left:8.0),
                                    child: new Text("ceo",style: new TextStyle(fontSize: 17.0, fontWeight: FontWeight.w400 ), ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        )



                  ),
                  new Divider(
                    color: Colors.black,
                    height: 1.0,
                  ),
                  new ListTile(
                    leading: Icon(Icons.dashboard),
                    title: new Text('DashBoard',style: new TextStyle(fontSize: 20.0)),
                    onTap: () {},
                  ),
                  new Divider(
                    color: Colors.black,
                    height: 1.0,
                  ),
                  new ListTile(
                    leading: Icon(Icons.settings),

                    title: new Text('Setting',style: new TextStyle(fontSize: 20.0)),
                    onTap: () {
                    },
                  ),
                  new Divider(
                    color: Colors.black,
                    height: 1.0,
                  ),
                  new ListTile(
                    leading: Icon(Icons.phone),
                    title: new Text('Contact Us',style: new TextStyle(fontSize: 20.0)),
                    onTap: () {},
                  ),
                  new Divider(
                    color: Colors.black,
                    height: 1.0,
                  ),
                  new ListTile(
                    leading: Icon(Icons.rate_review),
                    title:  new Text(log,style: new TextStyle(fontSize: 20.0)),
                    onTap: () {
                      waitfordetails(context);
                    },
                  ),
                  new Divider(
                    color: Colors.black,
                    height: 1.0,
                  ),
                ],
              )),
        ),

      ),
    );
  }
  ///////////////////////////
  Future<void> onDidReceiveLocalNotification(
      int id, String title, String body, String payload) async {
    // display a dialog with the notification details, tap ok to go to another page
    await showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          CupertinoDialogAction(
            isDefaultAction: true,
            child: Text('Ok'),
            onPressed: () async {
              Navigator.of(context, rootNavigator: true).pop();
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MyApp(),
                ),
              );
            },
          )
        ],
      ),
    );
  }


  ////////////////////////////
  void waitfordetails(BuildContext context) async {

    log="Login";
    // start the SecondScreen and wait for it to finish with a result
    final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => LoginPage(),
        ));

    // after the SecondScreen result comes back update the Text widget with it
    setState(() {
      text = result;
      if(text.compareTo('New User') != 0){
        log="Logout";
      }
    });
  }
}
class SecondScreen extends StatefulWidget {
  final String payload;
  SecondScreen(this.payload);
  @override
  State<StatefulWidget> createState() => SecondScreenState();
}

class SecondScreenState extends State<SecondScreen> {
  String _payload;
  @override
  void initState() {
    super.initState();
    _payload = widget.payload;
  }

  @override
  Widget build(BuildContext context) {

    return AlertDialog(
      title: new Text("Check the latest articles"),
      content: new Text("Get update on the latest news"),
      actions: <Widget>[
        // usually buttons at the bottom of the dialog
        new FlatButton(
          child: new Text("Read Now"),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }
}