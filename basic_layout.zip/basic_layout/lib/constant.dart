class Constant{
  static String base_url ="https://newsapi.org/v2/";
  static String key = "42a76172e4c545858b573d24328ebeb7";
}